<table width="100%" border="0" cellspacing="0" cellpadding="2" class="txt">
  <tr>
    <td id="heading">Welcome! Administration :: Payment Gateway::</td>
  </tr>
  <tr>
    <td>Welcome To admin panel....</td>
  </tr>
</table>
