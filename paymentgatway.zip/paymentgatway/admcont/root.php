<?php
$root = "../";
?>