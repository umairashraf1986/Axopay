<table>
        <?php foreach($_POST as $postkey => $postvalue) { ?>
        
                
                <tr><td><?php  echo $postkey; ?> </td><td> <?php  echo $postvalue; ?> </td></tr>
             
        <?php  }  ?>   

</table>
	