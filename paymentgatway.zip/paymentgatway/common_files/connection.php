<?php

include("../root.php");
include($root."includes/config.php");
include($root."includes/connect.php");

//include($root."common_files/site_functions.php");
//Including the Provider Classes
//include($root.'common_files/lang_config.php');

$url = "http://".$_SERVER['HTTP_HOST'];
$logo_path = "http://".$_SERVER['HTTP_HOST']."/pokeapanda/paymentgatway/images/axopaycom.png";

?>