<?php
$root = "http://dev.ejuicysolutions.com/pokeapanda/paymentgatway/paymentgatway/";
?>