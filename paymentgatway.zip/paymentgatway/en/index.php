<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to Axopay.com</title>
</head>

<body>
<div style="width:100%; height:500px;" align="center">
	
    <div style="width:238px; height:74px; margin-top:150px;" align="center">
    	<img border="0" src="<?php echo SURL?>en/images/axopaycom.png" width="238" height="74">
    </div>

</div>
</body>
</html>
