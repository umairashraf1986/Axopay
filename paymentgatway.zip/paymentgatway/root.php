<?php
$root = "../";
?>